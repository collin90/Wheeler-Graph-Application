dune build

cp ./_build/default/src/order.exe .
cp ./order.exe .. # copy to algorithms folder for the python usage

dune clean